﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace WebApplication7
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
            protected void Button2_Click(object sender, EventArgs e)
        {
            if (DropDownList1.SelectedIndex.Equals(1))
            {
                Response.Redirect("~/Webform2.aspx?");
            }
            else if (DropDownList1.SelectedIndex.Equals(2))
            {
                Response.Redirect("~/student.aspx?");
            }
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionStrings"].ConnectionString);
            conn.Open();
            SqlCommand cmdQuery = new SqlCommand("select * from exam", conn);
            conn.Open();
            SqlDataReader dr = cmdQuery.ExecuteReader();
            GridView1.DataSource = dr;
            GridView1.DataBind();
            conn.Close();
            
            
        }
    

        
    }
}
